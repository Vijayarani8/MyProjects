package steps;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import wdMethods.ProjectMethods;

public class Hooks extends ProjectMethods {
	@Before
	public void beforescenario(Scenario sc) {
		System.out.println(sc.getName());
		System.out.println(sc.getId());
		startResult();
		startTestModule("createLead", "createlead");
		test = startTestCase("Test Nodes");
		test.assignCategory("smoke");
		test.assignAuthor("Viji");
		startApp("chrome", "http://leaftaps.com/opentaps");
		
	}

	@After
	public void afterscenario(Scenario sc) {
		System.out.println(sc.getStatus());
		closeAllBrowsers();
		endResult();
	}

}
