package steps;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreateLead {
	/*ChromeDriver driver;
	@Given("Open the browser")
	public void openTheBrowser() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Given("Enter the URL")
	public void enterTheURL() {
		driver.get("http://leaftaps.com/opentaps");
		driver.manage().window().maximize();
	}

	@Given("Enter the username as (.*)")
	public void enterTheUsername(String uname) {
		driver.findElementById("username").sendKeys(uname);
		
	}

	@Given("Enter the Password as (.*)")
	public void enterThePassword(String pwd) {
		driver.findElementById("password").sendKeys(pwd);
		
	}

	@Given("Click login")
	public void clickLogin() {
		driver.findElementByClassName("decorativeSubmit").click();
	}

	@Given("Click CRM\\/SFA")
	public void clickCRMSFA() {
		driver.findElementByLinkText("CRM/SFA").click();
		
	}

	@Given("Click Create Lead")
	public void clickCreateLead() {
		driver.findElementByLinkText("Create Lead").click();
		
	}
	@Given("Input companyName as (.*)")
	public void inputCompanyName(String cname) {
		driver.findElementById("createLeadForm_companyName").sendKeys(cname);
	}

	@Given("Input FirstName as (.*)")
	public void inputFirstName(String fname) {
		driver.findElementById("createLeadForm_firstName").sendKeys(fname);
	}

	@Given("Input LastName as (.*)")
	public void inputLastName(String Lname) {
		driver.findElementById("createLeadForm_lastName").sendKeys(Lname);
	}

	@When("Create Lead")
	public void createLead() {
		driver.findElementByClassName("smallSubmit").click();
	}

	@Then("verfiy the creation of lead data is success")
	public void verfiyTheCreationOfLeadDataIsSuccess() {
		WebElement viewLead = driver.findElementByXPath("//div[@class='x-panel-header sectionHeaderTitle']");
		if(viewLead.getText().equals("View Lead")){
			System.out.println("Pass");
		}
		else {
			System.out.println("Fail");
		}
	}

*/
	
	

}
