package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.Given;
import wdMethods.ProjectMethods;

public class MyLeadsPage extends ProjectMethods {
	
	public MyLeadsPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.LINK_TEXT,using="Merge Leads") WebElement eleMergeLeads;
	@FindBy(how=How.LINK_TEXT,using="Create Lead") WebElement elecreateLeads;
	@FindBy(how=How.LINK_TEXT,using="Find Leads") WebElement eleFindLeads;
	
	
	public CreateLead eleclickCreateLead() {
		click(elecreateLeads);
		return new CreateLead();
	}
	public MergeLeadPage eleMergeLeads() {
		click(eleMergeLeads);
		return new MergeLeadPage();
	}
	public FindLeads eleFindLeads() {
		click(eleFindLeads);
		return new FindLeads();
	}
	
}
