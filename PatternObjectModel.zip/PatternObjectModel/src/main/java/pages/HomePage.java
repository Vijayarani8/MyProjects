package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.Given;
import wdMethods.ProjectMethods;

public class HomePage extends ProjectMethods{

	public HomePage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(how=How.LINK_TEXT, using="CRM/SFA") WebElement elecrmclick;
	@Given("Click CRM\\/SFA")
	public MyHome click() {
		click(elecrmclick);
		return new MyHome();
	}

	public void clickLogout() {
		// TODO Auto-generated method stub
		
	}

}










