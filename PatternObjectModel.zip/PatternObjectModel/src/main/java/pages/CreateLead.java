package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import wdMethods.ProjectMethods;

public class CreateLead extends ProjectMethods {
	
	public CreateLead() {
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(how=How.LINK_TEXT,using="Create Lead") WebElement createLead;
	@FindBy(how=How.ID,using="createLeadForm_companyName") WebElement elecompanyName;
	@FindBy(how=How.ID,using="createLeadForm_firstName") WebElement eleFirst;
	@FindBy(how=How.ID,using="createLeadForm_lastName") WebElement eleLast;
	@FindBy(how=How.CLASS_NAME,using="smallSubmit") WebElement eleclick;
	
	@Given("Click Create Lead")
	public CreateLead eleclickCreateLead() {
		click(createLead);
		return this;
	}
	@Given("Input companyName as (.*)")
	public CreateLead entercompanyName(String data) {
		type(elecompanyName, data);
		return this;
	}
	@Given("Input FirstName as (.*)")
	public CreateLead enterfirst(String data) {
		type(eleFirst, data);
		return this;
	}
	@Given("Input LastName as (.*)")
	public CreateLead enterLast(String data) {
		type(eleLast, data);
		return this;
	}
	@When("Create Lead")
	public ViewLead clicksubmit() {
		click(eleclick);
		return new ViewLead();
	}
	 
	

}
