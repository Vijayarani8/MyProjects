package pages;

public class duplicateLeadPage extends ViewLead {

}
