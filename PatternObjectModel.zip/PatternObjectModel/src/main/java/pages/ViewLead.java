package pages;

import org.hamcrest.Factory;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import wdMethods.ProjectMethods;

public class ViewLead extends ProjectMethods {

	public ViewLead() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(how=How.ID,using="viewLead_companyName_sp") WebElement text;
	@FindBy(how=How.LINK_TEXT,using="Find Leads") WebElement findLeads;
	@FindBy(how=How.CLASS_NAME,using="subMenuButtonDangerous") WebElement deleteButton;
	@FindBy(how=How.LINK_TEXT,using="Duplicate Lead") WebElement duplicate;

	public ViewLead duplicate() {
		click(duplicate);
		return new duplicateLeadPage;
	}
	public ViewLead verifytext(String data) {
		verifyPartialText(text, data);
		return this;
	}
	
	public FindLeads findLeads() {
		click(findLeads);
		return new FindLeads();
	}
	
	public MyLeadsPage delete() {
		click(deleteButton);
		return new MyLeadsPage();
	}

}
