package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.Given;
import wdMethods.ProjectMethods;

public class LoginPage extends ProjectMethods{

	public LoginPage() {
		PageFactory.initElements(driver, this);  
	}
	
	@FindBy(how=How.NAME, using="USERNAME") WebElement eleUname;
	@FindBy(how=How.ID, using="password") WebElement elePass;
	@FindBy(how=How.CLASS_NAME, using="decorativeSubmit") WebElement eleLogin;
	
	@Given("Enter the username as (.*)")
	public LoginPage enterUsername(String data) {
		type(eleUname, data);
		return this;
	}
	@Given("Enter the Password as (.*)")
	public LoginPage enterPassword(String data) {
		type(elePass, data);
		return this;
	}
	
	@Given("Click login")
	public HomePage clickLogin() {
		click(eleLogin);
		return new HomePage();
	}
	
}







