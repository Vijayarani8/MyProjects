package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import wdMethods.ProjectMethods;

public class MergeLeadPage extends ProjectMethods {
	
	public MergeLeadPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH, using="//input[@id='partyIdFrom']/following::img[1]") WebElement eleFromclick;
	@FindBy(how=How.XPATH, using="//input[@id='partyIdTo']/following::img[1]") WebElement eleToclick;
	@FindBy(how=How.CLASS_NAME, using="buttonDangerous") WebElement eleMerge;
	
	
	
	public FromToFindLeadsPage clickFromLead() {
		click(eleFromclick);
		
		return new FromToFindLeadsPage();
	}
	public FromToFindLeadsPage clickToLead() {
		click(eleToclick);
		return new FromToFindLeadsPage();
	}
	public FromToFindLeadsPage clickMerge() {
		click(eleMerge);
		return new FromToFindLeadsPage();
	}
	
	public ViewLead acceptalert() {
		driver.switchTo().alert().accept();
		return new ViewLead();
	}
}
