package pages;

import org.hamcrest.Factory;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import wdMethods.ProjectMethods;

public class FindLeads extends ProjectMethods {
	
	public FindLeads() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH,using="(//div[@class='x-form-clear-left']/preceding::input)[1]") WebElement eleFindLeadID;
	@FindBy(how=How.XPATH,using="//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a") WebElement eleLeadID;
	@FindBy(how=How.XPATH,using="//button[text()='Find Leads']") WebElement eleFindLeads;
	@FindBy(how=How.CLASS_NAME,using="x-form-text x-form-field") WebElement findLead;
	@FindBy(how=How.XPATH,using="(//a[@class='linktext'])[4]") WebElement firstEntry;
	
	public ViewLead firstEntry() {
		click(firstEntry);
		return new ViewLead();
	}
	
	public FindLeads eleEnterLeadId(String data) {
		type(eleFindLeadID, data);
		click(eleFindLeads);
		return this;
	}
	public FindLeads LeadId(String data) {
		type(findLead, data);
		click(eleFindLeads);
		return this;
	}
	public FindLeads eleLeadID(String data) {
		type(eleLeadID, data);
		click(eleFindLeads);
		return this;
	}
	
	

}
