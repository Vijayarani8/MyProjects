package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import wdMethods.ProjectMethods;

public class FromToFindLeadsPage extends ProjectMethods {

	public FromToFindLeadsPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH,using="//div[@class='x-form-element']/input[1]") WebElement eleFromID;
	@FindBy(how=How.XPATH,using="//button[text()='Find Leads']") WebElement elebuttonFind;
	@FindBy(how=How.XPATH,using="//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a") WebElement elefirstentry;
	@FindBy(how=How.XPATH,using="(//input[@id='partyIdTo']/following::a/img)[1]") WebElement eleToID;
	
	
	public FromToFindLeadsPage inputleadID(String data) {
		type(eleFromID, data);
		click(elebuttonFind);
		return this;
	}
	
	public FromToFindLeadsPage inputToleadID(String data) {
		type(eleToID, data);
		click(elebuttonFind);
		return this;
	}
	
	public MergeLeadPage selectfirstentry() {
		click(elefirstentry);
		return new MergeLeadPage();
	}
}
