package testcases;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import wdMethods.ProjectMethods;

public class TC004_DuplicateLead extends ProjectMethods{
	 
	@BeforeTest
	public void setData() {
		testCaseName = "TC004_duplicate";
		testDescription ="Login to leaftaps";
		testNodes = "Leads";
		authors ="Viji";
		category = "smoke";
		dataSheetName="TC004";
	}
	@Test(dataProvider="fetchData")
	public void loginLogout(String uname, String pwd, String LeadId) {
		new LoginPage()
		.enterUsername(uname)
		.enterPassword(pwd)  
		.clickLogin()
		.click()
		.clickLeads()
		.eleFindLeads()
		.LeadId(LeadId);
		
		
		
	}
	

}
