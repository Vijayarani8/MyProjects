package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import wdMethods.ProjectMethods;

public class TC002_CreateLead extends ProjectMethods {
	
	@BeforeTest
	public void setData() {
		testCaseName = "TC002_CreateLead";
		testDescription ="Create a Lead";
		testNodes = "Leads";
		authors ="Viji";
		category = "smoke";
		dataSheetName="TC002";
	}
	@Test(dataProvider="fetchData")
	public void CreateLead(String uname, String pwd, String comp, String first, String last) {
		String verifycomp = comp;
		new LoginPage() 
		.enterUsername(uname)
		.enterPassword(pwd)  
		.clickLogin()
		.click()
		.clickLeads()
		.eleclickCreateLead()
		.entercompanyName(verifycomp)
		.enterfirst(first)
		.enterLast(last)
		.clicksubmit()
		.verifytext(verifycomp);
		
	}

}



