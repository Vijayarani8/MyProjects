package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import wdMethods.ProjectMethods;

public class TC003_MergeLeads extends ProjectMethods {

	@BeforeTest
	public void setData() {
		testCaseName = "TC003_MergeLead";
		testDescription ="Merge Leads";
		testNodes = "Leads";
		authors ="Viji";
		category = "smoke";
		dataSheetName="TC003";
	}

	@Test(dataProvider="fetchData")
	public void MergeLead(String uname, String pwd, String fromId, String eleToID) {
		String LeadId = fromId;
		new LoginPage() 
		.enterUsername(uname)
		.enterPassword(pwd)  
		.clickLogin()
		.click()
		.clickLeads()
		.eleMergeLeads()
		.clickFromLead()
		.inputleadID(LeadId)
		.selectfirstentry()
		.clickToLead()
		.inputToleadID(eleToID)
		.selectfirstentry()
		.acceptalert()
		.findLeads()
		.eleEnterLeadId(LeadId);
		

	}
}


