package testcases;

public class TC005_DeleteLead {

}
